This package serves to provide visualizations from your NLP data.

This package was inspired by the work of NeptuneAI and this blog post:
https://neptune.ai/blog/exploratory-data-analysis-natural-language-processing-tools

This repository contains the Vizzy package and some sample notebooks to help you get started using Vizzy.



To install this package, you can use pip install

``pip install vizzy``

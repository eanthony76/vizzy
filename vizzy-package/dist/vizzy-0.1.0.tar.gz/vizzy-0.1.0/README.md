This package serves to provide visualizations from your NLP data. The Dataset class takes two arguments- a pandas dataframe and a column you wish to visualize.

The EDA techniques found in this package can be found at:

https://neptune.ai/blog/exploratory-data-analysis-natural-language-processing-tools
